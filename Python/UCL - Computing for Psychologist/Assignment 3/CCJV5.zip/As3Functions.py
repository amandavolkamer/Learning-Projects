class Buttons:
    def __init__(self, window, ui, dataList, playsound):
        self.ui = ui
        self.window = window
        self.dataList = dataList
        self.playsound = playsound

    # Functions to use in program - button clicks
    def P1Click(self):  # Goes to Consent Page
        self.ui.stackedWidget.setCurrentIndex(1)

    def P2ClicknoConsent(self):  # Goes to Consent Clarication Page
        self.ui.stackedWidget.setCurrentIndex(2)

    def BacktoTitlePage(self):  # Goes back to the Title Page
        self.ui.stackedWidget.setCurrentIndex(0)

    def P3ClicknoCorrect(self):  # Goes back to the Consent Page
        self.ui.stackedWidget.setCurrentIndex(1)

    def Soundclick(self):
        self.playsound('As3SoundCheck_trial.mp3')

    def P5Click(self):  # Goes to Instructions Page
        self.ui.stackedWidget.setCurrentIndex(5)
        #print("working")

    def P9Click(self):  # Goes to Exit Session Page
        self.ui.stackedWidget.setCurrentIndex(9)

class Consent:
    def __init__(self, window, ui):
        self.window = window
        self.ui = ui
        #self.dataList = dataList

    def P2ClickyesConsent(self): #Goes to Demo Page
        self.ui.stackedWidget.setCurrentIndex(3)
    def P2ClicknoConsent(self): #Goes to Consent Clarication Page
        self.ui.stackedWidget.setCurrentIndex(2)
    def BacktoTitlePage(self): #Goes back to the Title Page
        self.ui.stackedWidget.setCurrentIndex(0)
    def P3ClicknoCorrect(self): #Goes back to the Consent Page
        self.ui.stackedWidget.setCurrentIndex(1)

    def checkCheckbox(self):
        if self.ui.checkBox_5.isChecked() and self.ui.checkBox_4.isChecked() and self.ui.checkBox_3.isChecked() and self.ui.checkBox_2.isChecked() and self.ui.checkBox_1.isChecked():
            self.ui.stackedWidget.setCurrentIndex(3)
            #self.ui.IconsentButton.clicked.connect(Consent.P3ClicknoCorrect) #P2ClickyesConsent = ui.stackedWidget.setCurrentIndex(3)
            #print("CheckBox First Option")
        else:
            self.ui.ErrorLabel1.show()

    # Start anew if it is correct, need to refresh the checkboxes in cases they were checked before
    def refreshSettings(self):
        self.ui.checkBox_1.setCheckState(0)
        self.ui.checkBox_2.setCheckState(0)
        self.ui.checkBox_3.setCheckState(0)
        self.ui.checkBox_4.setCheckState(0)
        self.ui.checkBox_5.setCheckState(0)
        self.ui.ErrorLabel1.hide()

class DemoPage:
    def __init__(self, window, ui, dataList):
        self.window = window
        self.ui = ui
        self.dataList = dataList

    def P4Click(self):   #Goes to check sound page
        self.ui.stackedWidget.setCurrentIndex(4)

    # Page 4 - Demographics Page
    # stores age in list
    def storeAge(self):
        self.dataList.append(self.ui.AgeSpinBox.value())

    # Stores gender in list
    def storeGender(self):
        if self.ui.GenderBox.currentIndex() == 1:
            self.dataList.append("Female")
        elif self.ui.GenderBox.currentIndex() == 2:
            self.dataList.append("Male")

    # stores Education level
    def storeEducation(self):
        if self.ui.EducationBox.currentIndex() == 1:
            self.dataList.append("High School Degree")
        elif self.ui.EducationBox.currentIndex() == 2:
            self.dataList.append("Associates Degree")
        elif self.ui.EducationBox.currentIndex() == 3:
            self.dataList.append("Bachelors Degree")
        elif self.ui.EducationBox.currentIndex() == 4:
            self.dataList.append("Masters Degree")
        elif self.ui.EducationBox.currentIndex() == 5:
            self.dataList.append("Doctorate Degree")

    # stores ability option chosen
    def storeAbility(self):
        if self.ui.ImpairmentBox.currentIndex() == 1:  # "VI" for Visually Impaired
            self.dataList.append("VI")
        elif self.ui.ImpairmentBox.currentIndex() == 2:  # "HI" for Hearing Impaired
            self.dataList.append("HI")
        elif self.ui.ImpairmentBox.currentIndex() == 3:  # "B" for Both
            self.dataList.append("B")
        elif self.ui.ImpairmentBox.currentIndex() == 4:  # "N" for Neither
            self.dataList.append("N")

class Experiment:
    def __init__(self, window, ui, dataList):
        self.window = window
        self.ui = ui
        self.dataList = dataList

    def P6Click(self):   #Goes to First Experiment Page
        self.ui.stackedWidget.setCurrentIndex(6)

    def firstVidClick(self):
        if self.ui.BahButton1.isChecked() == True:
            self.dataList.append("Bah")
        elif self.ui.DahButton1.isChecked() == True:
            self.dataList.append("Dah")
        elif self.ui.FahButton1.isChecked() == True:
            self.dataList.append("Fah")
        elif self.ui.GahButton1.isChecked() == True:
            self.dataList.append("Gah")
        elif self.ui.SahButton1.isChecked() == True:
            self.dataList.append("Sah")
        elif self.ui.VahButton1.isChecked() == True:
            self.dataList.append("Vah")

    # Page 8 - click button to append Second Vid Sound Heard and to go to the Debrief Page

    def secVidClick(self):
        if self.ui.BahButton2.isChecked() == True:
            self.dataList.append("Bah")
        elif self.ui.DahButton2.isChecked() == True:
            self.dataList.append("Dah")
        elif self.ui.FahButton2.isChecked() == True:
            self.dataList.append("Fah")
        elif self.ui.GahButton2.isChecked() == True:
            self.dataList.append("Gah")
        elif self.ui.SahButton2.isChecked() == True:
            self.dataList.append("Sah")
        elif self.ui.VahButton2.isChecked() == True:
            self.dataList.append("Vah")

class miscellaneous():
    def __init__(self, window, ui, dataList, finalFile, finalFileRead):
        self.ui = ui
        self.window = window
        self.dataList = dataList
        self.finalFile = finalFile
        self.finalFileRead = finalFileRead

    def onblink(self):
        if self.ui.stackedWidget_2.currentIndex() == 0:
            self.ui.stackedWidget_2.setCurrentIndex(1)
        elif self.ui.stackedWidget_2.currentIndex() == 1:
            self.ui.stackedWidget_2.setCurrentIndex(2)
        else:
            self.ui.stackedWidget_2.setCurrentIndex(0)

    def saveData(self):
        self.finalFile.write(str(self.dataList) + "\n")
        self.finalFile.close()
        self.finalFileRead.close()

    # Page 10 - Exit Session Page
    def closeWindow(self):
        self.ui.stackedWidget.close()  # probably don't need this
        self.window.close()