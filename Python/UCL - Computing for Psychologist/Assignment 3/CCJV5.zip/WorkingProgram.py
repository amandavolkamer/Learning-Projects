import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from As3Functions import *
from Assessment3 import *
from Assessment3 import Ui_MainWindow
from playsound import playsound

import cv2 # To show video - visual
import numpy as np
# ffpyplayer for playing audio
from ffpyplayer.player import MediaPlayer
from Vid import * # Video functions module

QApplication.setAttribute(Qt.AA_EnableHighDpiScaling)

app = QApplication(sys.argv)
window = QMainWindow()
ui =  Ui_MainWindow()
ui.setupUi(window)

# opening the .csv file to record the results
finalFile = open("A3results.csv", "a")
finalFileRead = open("A3results.csv", "r")
allData = finalFileRead.readlines() # This is  for checking the previous participant's First Video to randomly assign
dataList = []
fileList = []
vidList = []

# Hide Error messages
ui.ErrorLabel1.hide()
ui.ageError.hide()
ui.errorLabel.hide()
ui.optionError.hide()
ui.optionError_3.hide()

# As3 Functions Module classes
but = Buttons(window, ui, dataList, playsound)
con = Consent(window, ui)
dem = DemoPage(window, ui, dataList)
exp = Experiment(window, ui, dataList)
mis = miscellaneous(window, ui, dataList, finalFile, finalFileRead)

# The 1st page of stacked widget - Title Page
ui.stackedWidget.setCurrentIndex(0)

# The blinking images of monkeys
blinkTimer = QTimer()
blinkTimer.timeout.connect(mis.onblink)
blinkTimer.start(250)
ui.BeginButton.clicked.connect(but.P1Click)

# Page 2 - Consent Page
ui.IconsentButton.clicked.connect(con.checkCheckbox)
ui.NoConsentButton.clicked.connect(but.P2ClicknoConsent)

# Page 3 - There is a clarification page if clicked "I do not consent" button.
# Loop back to consent page if not correct
# Start anew if it is correct, need to refresh the checkboxes in cases they were checked before
ui.YesButton.clicked.connect(con.refreshSettings) # refresh the checkboxes
ui.YesButton.clicked.connect(con.BacktoTitlePage)
ui.NoButton.clicked.connect(con.P3ClicknoCorrect)

# Page 4 - Demographics Page


def CheckValues():
    # If any of the boxes are not selected, an error message will show- If they are all selected, proceed to append
    if ui.AgeSpinBox.value() <17:
        ui.ageError.show()
    elif ui.GenderBox.currentIndex() == 0:
        ui.errorLabel.show()
    elif ui.EducationBox.currentIndex() == 0:
        ui.errorLabel.show()
    elif ui.ImpairmentBox.currentIndex() == 0:
        ui.errorLabel.show()
    else:
        ui.ContinueButton.clicked.connect(dem.storeAge)
        ui.ContinueButton.clicked.connect(dem.storeGender)
        ui.ContinueButton.clicked.connect(dem.storeEducation)
        ui.ContinueButton.clicked.connect(dem.storeAbility)
        ui.ContinueButton.clicked.connect(dem.P4Click)


ui.ContinueButton.clicked.connect(CheckValues)

# Page 5 - Sound Check
ui.SoundButton.clicked.connect(but.Soundclick) # will play a 15 second music to check for sounds in headphones
ui.readyButton.clicked.connect(but.P5Click)

# Page 6 - Experiment Instruction page
# Check against the previous participant's first video shown - Random order
if len(allData) > 0:
    conditionSplit = allData[-1].split(",")
    condition = conditionSplit[4]
    condition = condition.strip(" ''")
else:
    print(None)


def checkData1():
    if len(allData) > 0:
        # Assign Video B or V as the first video
        # 1 = Video B, 2 = Video V, whichever is NOT assigned will be the second Video shown
        # Appends the video into dataList for the .csv file
        if condition != 'B':
            dataList.append("B")
            ui.stackedWidget.setCurrentIndex(6)
            PlayVideo('VidBah_trial.avi', cv2, MediaPlayer)
        elif condition != "V":
            dataList.append("V")
            ui.stackedWidget.setCurrentIndex(6)
            PlayVideo('VidVah_trial.avi', cv2, MediaPlayer)
    else:
        dataList.append("B")
        ui.stackedWidget.setCurrentIndex(6)
        PlayVideo('VidBah_trial.avi', cv2, MediaPlayer)


ui.BeginStudyButton.clicked.connect(checkData1)

# Page 7 - click button to append First Vid Sound Heard and to go to the second trial (Second Experiment Page)


def firstVidCheck(self):
    if ui.BahButton1.isChecked() == False and ui.DahButton1.isChecked() == False and ui.FahButton1.isChecked() == False and ui.GahButton1.isChecked() == False and ui.SahButton1.isChecked() == False and ui.VahButton1.isChecked() == False:
        ui.optionError.show()
    else:
        if ui.BahButton1.isChecked() == True:
            dataList.append("Bah")
        elif ui.DahButton1.isChecked() == True:
            dataList.append("Dah")
        elif ui.FahButton1.isChecked() == True:
            dataList.append("Fah")
        elif ui.GahButton1.isChecked() == True:
            dataList.append("Gah")
        elif ui.SahButton1.isChecked() == True:
            dataList.append("Sah")
        elif ui.VahButton1.isChecked() == True:
            dataList.append("Vah")
        nextVid()
        ui.stackedWidget.setCurrentIndex(7)


def nextVid():
    if dataList[4] == "B": # the first video played determines the second video that will play for trial #2
        PlayVideo('VidVah_trial.avi', cv2, MediaPlayer)
    elif dataList[4] == "V":
        PlayVideo('VidBah_trial.avi', cv2, MediaPlayer)


ui.NextButton.clicked.connect(firstVidCheck)

# Page 8 - click button to append Second Vid Sound Heard and to go to the Debrief Page


def secVidCheck():
    if ui.BahButton2.isChecked() == False and ui.DahButton2.isChecked() == False and ui.FahButton2.isChecked() == False and ui.GahButton2.isChecked() == False and ui.SahButton2.isChecked() == False and ui.VahButton2.isChecked() == False:
        ui.optionError_3.show()
    else:
        exp.secVidClick()
        ui.stackedWidget.setCurrentIndex(8)


ui.NextButton2.clicked.connect(secVidCheck)

# Page 9 - Debrief Page
fileList.append(dataList)

if len(allData) > 0 :
    print(None)
else:
    title = "Age, Gender, Education Level, Ability, First Video Shown, First Vid Sound Heard, Second Vid Sound Heard"
    finalFile.write(title + "\n")
ui.ExitButton.clicked.connect(mis.saveData)
ui.ExitButton.clicked.connect(but.P9Click)

# Page 10 - Exit Session Page
ui.ExitSessionButton.clicked.connect(mis.closeWindow)
window.show()
sys.exit(app.exec_())